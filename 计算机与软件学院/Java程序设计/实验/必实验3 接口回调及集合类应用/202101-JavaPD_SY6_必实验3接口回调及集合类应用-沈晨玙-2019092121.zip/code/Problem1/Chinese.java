package Exp3_2.Problem1;

public class Chinese extends Human {
    public Chinese(String name) {
        super(name);
    }

    @Override
    public void sayHello() {
        System.out.println("你好！");
    }

}
