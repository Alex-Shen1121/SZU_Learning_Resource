//package Exp3_1;
//import Exp3_1.Problem4.DefaultClass;
//
//public class Problem4_2 {
//    public static void main(String[] args) {
//        DefaultClass test = new DefaultClass();
//        System.out.println("test.protected_val = " + test.protected_val);
//        System.out.println("test.public_val = " + test.public_val);
//    }
//}
