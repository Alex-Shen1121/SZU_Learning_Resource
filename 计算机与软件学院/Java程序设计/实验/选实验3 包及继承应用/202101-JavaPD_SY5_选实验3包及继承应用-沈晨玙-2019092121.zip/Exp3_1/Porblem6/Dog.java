package Exp3_1.Porblem6;

public class Dog extends Animal{
    public void run() {
        System.out.println("Dog类中调用run()");
    }

    public void eat() {
        System.out.println("Dog类中调用eat()");
    }
}
