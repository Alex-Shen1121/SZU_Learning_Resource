import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.util.regex.*;
import javax.swing.event.*;

public class Example10_11
{
	public static void main(String args[])
    {
		new PatternWindow();
    }
}

class PatternWindow extends JFrame implements DocumentListener,ActionListener
{
    JTextArea inputText,showText;
    JTextField patternText;
    Pattern p; //ģʽ����
    Matcher m; //ƥ�����
    
    PatternWindow()
    {
    	// ---
    	inputText = new JTextArea();
		showText = new JTextArea();
		
		// ---
		patternText = new JTextField("[^\\s\\d\\p{Punct}]+");
		patternText.addActionListener(this);
		add(patternText, BorderLayout.NORTH);
		
		// ---
		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(1, 2));
		panel.add(new JScrollPane(inputText));
		panel.add(new JScrollPane(showText));		
		add(panel, BorderLayout.CENTER);
				
		// ---
		validate();
	
		// ---
		(inputText.getDocument()).addDocumentListener(this); // ���ĵ�ע�������
		
		// ---
		setBounds(120, 120, 260, 270);
		setVisible(true);
		
		// ---
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }
    
    
    public void changedUpdate(DocumentEvent e)
    {
       hangdleText();
    }
    
    public void removeUpdate(DocumentEvent e)
    {
       changedUpdate(e); 
    }
    
    public void insertUpdate(DocumentEvent e)
    {
       changedUpdate(e);
    }
    
    public void hangdleText()
    {
       showText.setText(null);
       String s = inputText.getText();
       p = Pattern.compile(patternText.getText()); //��ʼ��ģʽ����
       m = p.matcher(s);                   
       while(m.find())
       {
    	   showText.append("��"+m.start()+"��"+m.end()+":");
           showText.append(m.group()+":\n");
       }
    }
    
    
    public void actionPerformed(ActionEvent e)
    {
    	hangdleText();
    }
}
