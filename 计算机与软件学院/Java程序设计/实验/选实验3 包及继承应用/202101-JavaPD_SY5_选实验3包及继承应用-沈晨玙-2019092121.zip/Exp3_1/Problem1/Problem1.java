package Exp3_1.Problem1;

public class Problem1 {
    public static void main(String[] args) {
        CSSE csse = new CSSE();
        csse.getTeacherNames();
    }
}
