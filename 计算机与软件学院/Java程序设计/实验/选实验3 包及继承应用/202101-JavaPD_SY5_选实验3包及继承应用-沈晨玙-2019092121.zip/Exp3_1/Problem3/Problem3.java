package Exp3_1.Problem3;

public class Problem3 {
    public static void main(String[] args) {
        System.out.println("I love SZU");
    }
}
