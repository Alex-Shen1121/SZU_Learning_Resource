package Exp3_1.Problem4;

class DefaultClass {
    protected int protected_val = 1;
    public int public_val = 2;
}
