package Exp3_1.Problem1;

public class Teacher {
    String name;
    String title;

    public Teacher(String name, String title) {
        this.name = name;
        this.title = title;
    }
}
