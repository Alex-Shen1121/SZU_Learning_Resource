package Exp3_1;

import cn.edu.szu.*;

public class Problem2 {
    public static void main(String[] args) {
        CSSE2 csse2 = new CSSE2();
        csse2.getTeacherNames();
    }
}
