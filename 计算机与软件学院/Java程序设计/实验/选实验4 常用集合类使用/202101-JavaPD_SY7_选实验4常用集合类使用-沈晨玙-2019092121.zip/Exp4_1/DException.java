package Exp4_1;

public class DException extends Exception{
    public void toShow(){
        System.out.println("属于危险品。");
    }
}
