import java.io.*;
import java.net.*;
import java.util.*;

public class MutiServer
{
	public static void main(String args[])
    {
		ServerSocket server = null;
        ServerThread thread;
        Socket socketAtServer = null;
        
        while(true) // !!
        {
        	try
        	{
        		server = new ServerSocket(4332);
            }
            catch(IOException e1)
            {
            	System.out.println("���ڼ���");   //ServerSocket�������ظ�����
            }
        	
            try
            {
            	socketAtServer = server.accept();            	            	
            	System.out.println("�ͻ��ĵ�ַ:" + socketAtServer.getInetAddress());
            }
            catch (IOException e)
            {
            	System.out.println("���ڵȴ��ͻ�");
            }
            
            if(socketAtServer!=null)
            {
                 new ServerThread(socketAtServer).start(); //Ϊÿ���ͻ�����һ��ר�ŵ��߳�
            }
            else
            {
            	continue;
            }
        }
    }
}

class ServerThread extends Thread
{
    Socket socket;
    DataOutputStream out = null;
    DataInputStream in = null;
    String s = null;
    
    ServerThread(Socket t)
    {
       socket = t;
       try
       {
    	   in = new DataInputStream(socket.getInputStream());
    	   out = new DataOutputStream(socket.getOutputStream());
       }
       catch (IOException e){}
    }
    
    public void run()
    {
    	while(true)
    	{
    		double a=0,b=0,c=0,root1=0,root2=0;
    		try
    		{
    			a = in.readDouble(); //����״̬�����Ƕ�ȡ����Ϣ
    			b = in.readDouble(); 
    			c = in.readDouble(); 
    			
    			double disk=b*b-4*a*c;
    			root1 = (-b+Math.sqrt(disk))/(2*a);
    			root2 = (-b-Math.sqrt(disk))/(2*a);
    			
    			out.writeDouble(root1);
    			out.writeDouble(root2);
           }
           catch (IOException e)
           {
        	   System.out.println("�ͻ��뿪");
        	   break;
           }
       }
    }    
    
}
