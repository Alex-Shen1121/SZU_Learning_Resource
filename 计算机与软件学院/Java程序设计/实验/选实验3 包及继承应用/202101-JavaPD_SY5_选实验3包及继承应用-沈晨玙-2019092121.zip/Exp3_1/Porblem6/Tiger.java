package Exp3_1.Porblem6;

public class Tiger extends Animal {
    public void run() {
        System.out.println("Tiger类中调用run()");
    }

    public void eat() {
        System.out.println("Tiger类中调用eat()");
    }
}
