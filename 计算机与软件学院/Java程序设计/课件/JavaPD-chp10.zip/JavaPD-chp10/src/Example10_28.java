import java.awt.*; 
import java.awt.event.*;
import javax.swing.*;

public class Example10_28
{
	public static void main(String args[])
	{
		MVCWin win = new MVCWin();
	}
}

// ---
class Lader
{
	private double above, bottom, height, area;
	public double getArea()
	{
		return (above+bottom)*height/2;
	}
	
	public void setAbove(double above)
	{
		this.above=above;
	}
	
	public void setBottom(double bottom)
	{
		this.bottom=bottom;
	}
	
	public void setHeight(double height)
	{
		this.height=height;
	}
}

// ---
class MVCWin extends JFrame implements ActionListener
{
	Lader lader;                                 //���ݶ���
	JTextField textAbove,textBottom,textHeight;      //���ݶ������ͼ
	JTextArea showArea;                         //���ݶ������ͼ
	JButton controlButton;                        //����������
	MVCWin()
	{
		lader=new Lader();
		
		// ---
		textAbove=new JTextField(5);   
		textBottom=new JTextField(5);
		textHeight=new JTextField(5);
		showArea=new JTextArea();
		
		// ---
		controlButton=new JButton("�������");
		
		// ---
		JPanel pNorth=new JPanel();
		pNorth.add(new JLabel("�ϵ�:"));
		pNorth.add(textAbove);
		pNorth.add(new JLabel("�µ�:"));
		pNorth.add(textBottom);
		pNorth.add(new JLabel("��:"));
		pNorth.add(textHeight); 
		pNorth.add(controlButton); 
		
		// ---
		controlButton.addActionListener(this);
		
		// ---
		add(pNorth,BorderLayout.NORTH);
		add(new JScrollPane(showArea),BorderLayout.CENTER);
		
		// ---
		setBounds(100,100,630,160);
		setVisible(true);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}
	
	
	public void actionPerformed(ActionEvent e)
	{
		try{
			double a=Double.parseDouble(textAbove.getText().trim());   
			double b=Double.parseDouble(textBottom.getText().trim());      
			double c=Double.parseDouble(textHeight.getText().trim()); 
			lader.setAbove(a) ;          //��������
			lader.setBottom(b);
			lader.setHeight(c);
			showArea.append("���ε����:"+lader.getArea()+"\n");//������ͼ
		} 
		catch(Exception ex)
		{
			showArea.append("\n"+ex+"\n");
		}
	}
}
