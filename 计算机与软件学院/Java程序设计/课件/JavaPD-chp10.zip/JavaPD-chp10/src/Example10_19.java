import java.awt.event.*; 
import javax.swing.*;
import java.awt.*;

public class Example10_19
{
    public static void main(String args[])
    {
        new FontWin();
    }
}

class FontWin extends JFrame implements ItemListener
{
    JComboBox listFont;
    JTextArea text;
    FontWin()
    {	
    	// ---
    	GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
    	String fontName[] = ge.getAvailableFontFamilyNames();
    	listFont = new JComboBox(fontName);
    	listFont.addItemListener(this);
    	
    	// ---
    	JPanel pNorth = new JPanel();
    	pNorth.add(listFont); 
    	add(pNorth,BorderLayout.NORTH);
    	
    	// ---
    	text = new JTextArea(12,12);
    	add(new JScrollPane(text), BorderLayout.CENTER);
    	
    	// ---
    	setBounds(100,120,300,300);    	
    	setVisible(true);
    	
    	// ---
    	setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    	
    }
    
    public void itemStateChanged(ItemEvent e)
    {
    	String name = (String)listFont.getSelectedItem();
    	Font f = new Font(name, Font.BOLD, 32);
    	text.setFont(f);
    	text.setText("Shenzhen University");
    }
}
