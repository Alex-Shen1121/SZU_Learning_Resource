package Exp3_1.Porblem6;

public class Problem6 {
    public static void main(String[] args) {
        Animal animal = new Animal();
        animal.test();

        Animal tiger = new Tiger();
        tiger.test();

        Animal cat = new Cat();
        cat.test();

        Animal dog = new Dog();
        dog.test();

    }
}
