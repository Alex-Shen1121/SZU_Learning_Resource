package Exp3_1.Problem7;

public interface Computable {
    public abstract void add(Vector v1);

    public abstract void minus(Vector v1);
}
