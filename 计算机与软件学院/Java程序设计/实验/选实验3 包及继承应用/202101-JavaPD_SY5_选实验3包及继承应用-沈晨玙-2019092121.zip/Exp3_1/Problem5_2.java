package Exp3_1;
import Exp3_1.Problem5.PublicClass;

public class Problem5_2 {
    public static void main(String[] args) {
        PublicClass test = new PublicClass();
//        System.out.println("test.protected_val = " + test.protected_val);
        System.out.println("test.public_val = " + test.public_val);
    }
}
