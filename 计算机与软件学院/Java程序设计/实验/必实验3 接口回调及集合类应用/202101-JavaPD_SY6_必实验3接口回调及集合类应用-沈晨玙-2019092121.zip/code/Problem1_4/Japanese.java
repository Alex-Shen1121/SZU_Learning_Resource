package Exp3_2.Problem1_4;

public class Japanese implements Human{
    @Override
    public void sayHello() {
        System.out.println("こんにちは!");
    }
}
