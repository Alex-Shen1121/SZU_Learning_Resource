import javax.swing.*; 
import java.awt.*;

public class Example10_4
{
    public static void main(String args[])
    {
        new MyWin();
    }
}


class MyWin extends JFrame
{
    JTabbedPane p;
    Icon icon[];
    String imageName[] = {"a.jpg", "b.jpg", "c.jpg", "d.jpg", "e.jpg"};
    
    public MyWin()
    {
		// ---
		icon = new Icon[imageName.length];		
		for(int i=0; i<icon.length; i++)
		{
			icon[i] = new ImageIcon(imageName[i]);
		}
		
		// ---
		p = new JTabbedPane(JTabbedPane.LEFT);		
		for(int i=0; i<icon.length; i++)
		{
			int i2 = i + 1;
			p.add("�ۿ���" + i2 + "��ͼƬ", new JButton(icon[i]));
		}
		
		// ---
		add(p, BorderLayout.CENTER);
		
		// ---
		p.validate();
		
		// ---
		validate();

		// ---
		setBounds(100, 100, 500, 300);		
		setVisible(true);
		
		// ---
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }
}
