import java.net.*;  
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class ClientFrame extends JFrame implements Runnable,ActionListener
 {
	JButton connection,computer;
	JTextField inputA,inputB,inputC;
	JTextArea showResult;
	Socket socket = null;
    DataInputStream in = null; 
    DataOutputStream out = null;
    Thread thread; 
    
    public ClientFrame()
    {
    	// ---
    	socket = new Socket(); //�����ӵ��׽���
    	
    	// ---
        connection = new JButton("���ӷ�����");
        connection.addActionListener(this);
        
        // ---
        computer = new JButton("�󷽳̵ĸ�");
        computer.setEnabled(false);         //û�кͷ���������֮ǰ���ð�ť������
        computer.addActionListener(this);        
        
        // ---
        inputA = new JTextField("0",12);
        inputB = new JTextField("0",12);
        inputC = new JTextField("0",12);
        
        // ---
        Box boxV1 = Box.createVerticalBox();
        boxV1.add(new JLabel("����2����ϵ��"));
        boxV1.add(new JLabel("����1����ϵ��"));
        boxV1.add(new JLabel("���볣����"));
        Box boxV2 = Box.createVerticalBox();
        boxV2.add(inputA);
        boxV2.add(inputB);
        boxV2.add(inputC);
        Box baseBox = Box.createHorizontalBox();
        baseBox.add(boxV1);
        baseBox.add(boxV2);
        
        // ---
        showResult = new JTextArea(8,18);
        
        // ---
        Container con = getContentPane();
        con.setLayout(new FlowLayout());        
        con.add(connection);
        con.add(baseBox);
        con.add(computer);
        con.add(new JScrollPane(showResult));
        
        // ---
        setBounds(100,100,360,310);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // ---
        thread = new Thread(this);
    }
    
    public void run()
    {
    	while(true)
    	{
    		try
    		{
    			double root1 = in.readDouble(); //����״̬�����Ƕ�ȡ����Ϣ
    			double root2 = in.readDouble(); 
    			showResult.append("\n������:\n"+root1+"\n"+root2);
    			showResult.setCaretPosition((showResult.getText()).length());
    		}
    		catch(IOException e)
    		{
    			showResult.setText("��������ѶϿ�");
    			computer.setEnabled(false);
    			break;
    		}
        }
    }
    
    public void actionPerformed(ActionEvent e)
    {
    	if(e.getSource()==connection)
    	{
    		try
    		{
    			if(socket.isConnected())
    			{
    			}
                else
                {
                	// ---
                	InetAddress address = InetAddress.getByName("127.0.0.1");
                   
                	InetSocketAddress socketAddress = new InetSocketAddress(address,4332);
                   
                	// ---
                	socket.connect(socketAddress);
                   
                	// ---
                	in=new DataInputStream(socket.getInputStream());
                   
                	// ---
                	out=new DataOutputStream(socket.getOutputStream());
                   
                	// ---
                	computer.setEnabled(true);
                	//thread.start();
                }
           }
           catch (IOException ee)
           {
        	   System.out.println(ee);
        	   socket=new Socket();
           }
        }
    	
        if(e.getSource()==computer)
        {
           try
           {
        	   double  a = Double.parseDouble(inputA.getText()),
        			   b = Double.parseDouble(inputB.getText()),
        			   c = Double.parseDouble(inputC.getText());
                double disk=b*b-4*a*c;
                if(disk>=0)
                {
                	out.writeDouble(a);
                	out.writeDouble(b);
                	out.writeDouble(c);
                	
                	// !!!
                	double root1 = in.readDouble(); //����״̬�����Ƕ�ȡ����Ϣ
        			double root2 = in.readDouble(); 
        			showResult.append("\n������:\n"+root1+"\n"+root2);
        			showResult.setCaretPosition((showResult.getText()).length());
                }
                else
                {
                	inputA.setText("��2�η�����ʵ��");
                }
           }
           catch(Exception ee)
           {
                inputA.setText("�����������ַ�");
           }
        }
    }
    
    public static void main(String args[])
    {
    	ClientFrame win = new ClientFrame();
    }
    
}