package Exp3_2.Problem1;

public abstract class Human {
    String name;

    public Human(String name) {
        this.name = name;
    }

    public abstract void sayHello();
}
