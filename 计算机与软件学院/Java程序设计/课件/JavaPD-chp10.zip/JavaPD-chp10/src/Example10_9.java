import java.awt.*; 
import java.awt.event.*;
import javax.swing.*;
import java.math.*;

public class Example10_9
{
	public static void main(String args[])
	{
		MathWindow win=new MathWindow();
    }
}


class MathWindow extends JFrame
{
	JTextField inputText,showText;
    MathWindow()
    {
    	// ---
    	inputText = new JTextField(10);
    	add(inputText); 
               
        // ---
    	showText = new JTextField(10);
    	add(showText);
    	    	
        // ---
        inputText.addActionListener(new ActionListener()
        {
        	public void actionPerformed(ActionEvent e)
        	{
        		String s = inputText.getText();
        		try
        		{
        			BigInteger n = new BigInteger(s); 
        			n = n.pow(2);
                    showText.setText(n.toString());
        		}
                catch(NumberFormatException e2)
                {
                	showText.setText("�����������ַ�");
                    inputText.setText(null);
                }
        	}
        });
        
        // ---
        setLayout(new FlowLayout());
        
        // ---
        validate();
        
        // ---
        setBounds(100,100,260,190);
        setVisible(true);
        
        // ---
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }
}
