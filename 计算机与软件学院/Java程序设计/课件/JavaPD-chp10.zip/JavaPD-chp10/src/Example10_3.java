import javax.swing.*;
import java.awt.*; 

public class Example10_3
{    
	public static void main(String args[])
    {
		// ---
		JFrame win = new JFrame("����"); 
                
		// ---
        JButton bSouth = new JButton("��");
        JButton bNorth = new JButton("��");
        JButton bEast = new JButton("��");
        JButton bWest = new JButton("��");        
        JTextArea bCenter = new JTextArea("����");
        
        // ---
        win.add(bNorth, BorderLayout.NORTH);
        win.add(bSouth, BorderLayout.SOUTH);
        win.add(bEast, BorderLayout.EAST);
        win.add(bWest, BorderLayout.WEST); 
        win.add(bCenter, BorderLayout.CENTER);
        
        // ---
        win.validate();
        
        // ---
        win.setBounds(100,100,300,300);
        win.setVisible(true);
        
        // ---
        win.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
