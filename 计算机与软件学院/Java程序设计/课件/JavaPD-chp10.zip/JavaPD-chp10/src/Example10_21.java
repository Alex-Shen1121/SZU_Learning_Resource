import java.awt.*; 
import java.awt.event.*;
import javax.swing.*;

public class Example10_21
{
    public static void main(String args[])
    {
        new MouseWindow();
    }
}

class MouseWindow extends JFrame implements MouseListener
{
    JButton button;
    JTextArea textArea;
    MouseWindow()
    {
    	// ---
        setLayout(new FlowLayout());
        
        // ---
        addMouseListener(this);
                
        // ---
        button = new JButton("���ǰ�ť"); 
        button.addMouseListener(this);
        
        // ---
        textArea = new JTextArea(8,18);
        
        // ---
        add(button);
        add(new JScrollPane(textArea));
        
        // ---
        setBounds(100,100,350,280);
        setVisible(true);
        validate();        
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
        
    // ---    
    public void mousePressed(MouseEvent e)
    {
        textArea.append("\n��갴��,λ��:"+"("+e.getX()+","+e.getY()+")");
    }
    
    // ---    
    public void mouseReleased(MouseEvent e)
    {
    	if(e.getSource()==button)
    	{
    		textArea.append("\n�ڰ�ť������ɿ�,λ��:"+"("+e.getX()+","+e.getY()+")");
    	}
    }
    
    // ---
    public void mouseEntered(MouseEvent e)
    {
    	if(e.getSource()==button)
    	{
    		textArea.append("\n�����밴ť,λ��:"+"("+e.getX()+","+e.getY()+")");
    	}
    }

    // ---
    public void mouseExited(MouseEvent e){}
    
    // ---
    public void mouseClicked(MouseEvent e)
    {
    	if(e.getModifiers()==InputEvent.BUTTON3_MASK && e.getClickCount()>=2)
    	{
    		textArea.setText("��˫��������Ҽ�");
    	}
    }
}
