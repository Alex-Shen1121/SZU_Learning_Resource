import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

public class Example10_10
{
    public static void main(String args[])
    {
    	EditWindow win = new EditWindow("����");
    }
}


class EditWindow extends JFrame implements ActionListener
{
	JMenuBar menubar;
    JMenu menu;
    JSplitPane splitPane;
    JMenuItem itemCopy,itemCut,itemPaste; 
    JTextArea text1,text2;
    
    // ---
    EditWindow(String s)
    {
    	// ---
		setTitle(s);
		setSize(260, 270);
		setLocation(120, 120);
		setVisible(true);
		
		// ---
		itemCopy = new JMenuItem("����");
		itemCut = new JMenuItem("����");
		itemPaste = new JMenuItem("ճ��");
		
		// ---
		itemCopy.addActionListener(this);
		itemCut.addActionListener(this);
		itemPaste.addActionListener(this);
		
		// ---
		menu = new JMenu("�༭");
		menu.add(itemCopy);
		menu.add(itemCut);
		menu.add(itemPaste);
		
		
		// ---
		menubar = new JMenuBar();
		menubar.add(menu);
		setJMenuBar(menubar);
		
		// ---
		text1 = new JTextArea();
		text2 = new JTextArea();
		splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, text1, text2);
		splitPane.setDividerLocation(120);
		add(splitPane, BorderLayout.CENTER);
		
		// ---
		validate();
		
		// ---
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    } 
    
    // ---
    public void actionPerformed(ActionEvent e)
    {
       if(e.getSource() == itemCopy)
       {
           text1.copy();
       }
       else 
       {
    	   if(e.getSource() == itemCut)
    	   {
    		   text1.cut();
    	   }
    	   else 
    	   {
    		   if(e.getSource()==itemPaste)
    		   {
    			   text2.paste();
    		   }
    	   }
       }
    }
    
}
