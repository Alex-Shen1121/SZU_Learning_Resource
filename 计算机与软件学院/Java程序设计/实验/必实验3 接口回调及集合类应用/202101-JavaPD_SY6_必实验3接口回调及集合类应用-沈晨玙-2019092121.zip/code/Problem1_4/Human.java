package Exp3_2.Problem1_4;

public interface Human {
    void sayHello();
}
