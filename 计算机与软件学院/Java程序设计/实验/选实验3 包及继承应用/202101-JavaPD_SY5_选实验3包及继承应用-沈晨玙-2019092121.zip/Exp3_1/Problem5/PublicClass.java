package Exp3_1.Problem5;

public class PublicClass {
    protected int protected_val = 1;
    public int public_val = 2;
}
