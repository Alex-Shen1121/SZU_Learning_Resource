import javax.swing.*;
import java.awt.event.InputEvent; 
import java.awt.event.KeyEvent;

public class Example10_1
{
	public static void main(String args[])
	{
		FirstWindow win = new FirstWindow("һ���򵥵Ĵ���");
    }
}


class FirstWindow extends JFrame
{
    JMenuBar menubar;
    JMenu menu;
    JMenuItem item1,item2;

    FirstWindow(String s)
    {
    	// ---
    	setTitle(s);
    	
    	// ---
    	item1 = new JMenuItem("��", new ImageIcon("open.gif"));
    	item2 = new JMenuItem("����", new ImageIcon("save.gif"));
		item1.setAccelerator(KeyStroke.getKeyStroke('O'));
		item2.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, InputEvent.CTRL_MASK));
		
		// ---
		menu = new JMenu("�ļ�");
		menu.add(item1);
		menu.addSeparator();
		menu.add(item2);

    	// ---
    	menubar = new JMenuBar();		
		menubar.add(menu);
		
		// ---
		setJMenuBar(menubar);
		
		// ---
		validate();
		
		// ---
		setSize(160,170);
    	setLocation(120,120);
    	setVisible(true);
    	
    	// ---
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    } 
}
