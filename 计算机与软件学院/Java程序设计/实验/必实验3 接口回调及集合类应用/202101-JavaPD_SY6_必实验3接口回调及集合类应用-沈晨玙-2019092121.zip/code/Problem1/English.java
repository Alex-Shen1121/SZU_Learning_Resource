package Exp3_2.Problem1;

public class English extends Human {
    public English(String name) {
        super(name);
    }

    @Override
    public void sayHello() {
        System.out.println("Hello!");
    }
}
